package bOf3;

public class Triangle extends Shape{

    @Override
    public void displayArea() {
        System.out.println("Area of Triangle: " + 0.5 * height * width);
    }
}
