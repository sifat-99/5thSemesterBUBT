package bOf3;

public class Rectangle extends Shape{

    @Override
    public void displayArea() {
        System.out.println("Area of Rectangle: " + height * width);
    }
}
