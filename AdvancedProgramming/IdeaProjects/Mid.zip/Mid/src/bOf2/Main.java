package bOf2;

public class Main {
    public static void main(String[] args) {
    Grandfather grandfather = new Grandfather(70, "John");
    Father father = new Father(45, "Tom");
    Son son = new Son(25, "Jerry");
    grandfather.showDetails();
    father.showDetails();
    son.showDetails();
    }
}
