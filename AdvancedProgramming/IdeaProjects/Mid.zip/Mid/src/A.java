public class A {
    public void showA(){
        System.out.println("intake 49....");
    }
}
