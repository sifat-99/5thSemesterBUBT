interface C {
    void showA();
}
