package Vehicle;

public interface Vehicle {
    void getSpeed();
}
