interface D{
    void showB();
}
